def display_lands(lands):
    print("Land Details:")
    print("=========================================================================")
    print("| Kitta Number | City       | Direction | Ana | Price        | Availability |")
    print("=========================================================================")
    for land in lands:
        print("| " + str(land['kitta_number']).ljust(12) + " | " + str(land['city']).ljust(10) + " | " + str(land['direction']).ljust(9) + " | " + str(land['ana']).rjust(3) + " | Rs. " + str(land['price']).rjust(9) + " | " + str(land['availability']).ljust(12) + " |")
    print("=========================================================================")


def return_land(lands, kitta_number):
    while True:
        for land in lands:
            if land['kitta_number'] == kitta_number:
                if land['availability'] == "Not Available":
                    actual_months = int(input("Enter the actual number of months rented: "))
                    if actual_months <= 0:
                        print("Invalid input. Please enter a valid number of months.")
                        return

                    if actual_months > 0:
                        if actual_months > land['months_rented']:
                            extra_months = actual_months - land['months_rented']
                            fine = 0.10 * (extra_months * land['price'])
                            total_price = land['price'] * actual_months
                            final_price = total_price + fine

                            print("You rented the land for " + str(actual_months) + " months, exceeding the agreed-upon period. " +
                                  "Total price: Rs. " + str(total_price) + ", fine: Rs. " + str(fine) + ". " +
                                  "Total amount with fine: Rs. " + str(final_price) + " will be applied.")
                        else:
                            print("Land " + str(kitta_number) + " has been returned.")

                        land['availability'] = "Available"
                        land['months_rented'] = 0
                        
                        
                    

                        # Generate invoice for returned land and save to file
                        invoice = "==========================\n"
                        invoice += "Return Invoice\n"
                       
                        invoice += "Land Kitta Number: " + str(kitta_number) + "\n"
                        invoice += "City: " + land['city'] + "\n"
                        invoice += "Direction: " + land['direction'] + "\n"
                        invoice += "Returned Months: " + str(actual_months) + "\n"
                        invoice += "Total Price: Rs. " + str(total_price) + "\n"
                        invoice += "Fine: Rs. " + str(fine) + "\n"
                        invoice += "Price after Fine: Rs. " + str(final_price) + "\n"
                        invoice += "==========================\n"

                        # Print the invoice in the shell
                        print(invoice)

                        # Write the invoice to the file
                        with open("return_invoice_land.txt", 'a') as return_file:
                            return_file.write(invoice)

                        # Update land availability and clear customer details in land_info.txt
                        with open("land_info.txt", 'w') as land_file:
                            for l in lands:
                                if l['kitta_number'] == kitta_number:
                                    l['availability'] = "Available"
                                    l['months_rented'] = 0
                                    l['customer_name'] = ""  
                                    l['customer_number'] = ""  # 
                                land_file.write(str(l['kitta_number']) + "," + l['city'] + "," + l['direction'] + "," + str(l['ana']) + "," + str(l['price']) + "," + l['availability'] + "\n")
                        
                        return
                else:
                    print("Land " + str(kitta_number) + " is available.")
                    return
        else:
            print("Kitta Number not found!")
            return





def rent_land(lands, kitta_number):
    #
    with open("invoice_land.txt", 'a') as file:
        while True:
            for land in lands:
                if land['kitta_number'] == kitta_number:
                    if land['availability'] == "Available":
                        
                        customer_name = input("Enter customer name: ")
                        customer_number = input("Enter phone number: ")
                        
                        available_ana = land['ana']  

                      
                        ana = int(input("Enter the area (Ana) of the land: "))

                        if ana == available_ana:
                            while True:
                                try:
                                    months = int(input("Enter number of months to rent: "))
                                    if months > 0:
                                        break
                                    else:
                                        print("Number of months should be greater than 0. Please try again.")
                                except ValueError:
                                    print("Invalid input. Please enter a valid number.")

                            # Update land availability and months rented
                            land['availability'] = "Not Available"
                            land['months_rented'] = months

                            # Calculate total price
                            total_price = land['price'] * months

                            # Generate invoice and save to file
                            invoice = "==========================\n"
                            invoice += "Invoice\n"
                            invoice += "Customer Name: " + customer_name + "\n"
                            invoice += "Phone Number: " + customer_number + "\n"
                            invoice += "Land Kitta Number: " + str(kitta_number) + "\n"
                            invoice += "City: " + land['city'] + "\n"
                            invoice += "Direction: " + land['direction'] + "\n"
                            invoice += "Land Area: " + str(ana) + " Ana\n"
                            invoice += "Total Months: " + str(months) + "\n"
                            invoice += "Total Price: Rs. " + str(total_price) + "\n"
                            invoice += "==========================\n"

                            # Write invoice to the file
                            file.write(invoice)

                            # Print invoice to shell
                            print("Invoice:")
                            print(invoice)

                            # Update land availability in land_info.txt
                            with open("land_info.txt", 'w') as land_file:
                                for l in lands:
                                    if l['kitta_number'] == kitta_number:
                                        l['availability'] = "Not Available"
                                    land_file.write(str(l['kitta_number']) + "," + l['city'] + "," + l['direction'] + "," + str(l['ana']) + "," + str(l['price']) + "," + l['availability'] + "\n")

                            # Ask if the user wants to rent another land
                            choice = input("Do you want to rent another land? (yes/no): ")
                            if choice == "yes":
                                # Ask for another kitta number to rent
                                kitta_number = int(input("Enter Kitta Number to rent: "))
                                break  
                            else:
                                return  
                        else:
                            print("Land with " + str(ana) + " Ana is not available for rent.")
                            break
                    else:
                        print("Land " + str(kitta_number) + " is already rented.")
                    break
            else:
                print("Kitta Number " + str(kitta_number) + " not found! Please try again")
                break  # Exit the loop if the kitta number is not found
