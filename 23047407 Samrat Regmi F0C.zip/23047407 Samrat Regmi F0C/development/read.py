def read_lands_from_file():
    lands = []
    try:
        with open("land_info.txt", "r") as file:
            for line in file:
                if not line.strip():
                    continue

                land_info = line.strip().split(',')
                if len(land_info) == 6:
                    try:
                        kitta_number, city, direction, ana, price, availability = land_info
                        lands.append({
                            'kitta_number': int(kitta_number),
                            'city': city,
                            'direction': direction,
                            'ana': int(ana),
                            'price': int(price),
                            'availability': availability
                        })
                    except ValueError:
                        print("Invalid data format in land_info.txt:", line)
                        continue
                else:
                    print("Invalid data format in land_info.txt:", line)
    except FileNotFoundError:
        print("Error: land_info.txt not found.")
    return lands
