from read import read_lands_from_file
import operation

lands = read_lands_from_file()

if lands:
    print("-" * 184)
    print("\t\t\t\t\t\t\t\t\t\t\tSamrat Rental Nepal")
    print("\n")
    print("\t\t\t\t\t\t\t\t\t\tRamkot, Kathmandu | Phone no: 98526718912")
    print("\n")
    print("-" * 184)
    print("\t\t\t\t\t\t\t\t\t\tWelcome to the system. We hope you have a good experience.")
    print("-" * 184)

select = True

while select:
    print("\n1. Show land details")
    print("2. Rent Land to customer")
    print("3. Return land from customer")
    print("4. Exit")

    try:
        choice = input("Enter your choice: ")

        if choice == '1':
            operation.display_lands(lands)

        elif choice == '2':
            operation.display_lands(lands)
            kitta_number = int(input("Enter Kitta Number: "))
            operation.rent_land(lands, kitta_number)

        elif choice == '3':
            kitta_number = int(input("Enter Kitta Number to return: "))
           
            operation.return_land(lands, kitta_number)

        elif choice == '4':
            print("Thank you for visiting")
            select = False

        else:
            print("*"*86)
            print("You can only select option from 1,2 and 3.")
            print("*"*86)

    except:
        print("*"*86)
        print("Error !! please try again !\n")
        print("*"*86)
