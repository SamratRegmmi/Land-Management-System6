def write_invoice_to_file(kitta_number, customer_name, customer_number, land, ana, months, total_price):
    # Generate invoice
    invoice = "==========================\n"
    invoice += "Invoice\n"
    invoice += "Customer Name: " + customer_name + "\n"
    invoice += "Phone Number: " + customer_number + "\n"
    invoice += "Kitta Number: " + str(kitta_number) + "\n"  
    invoice += "City: " + land['city'] + "\n"
    invoice += "Direction: " + land['direction'] + "\n"
    invoice += "Land Area: " + str(ana) + " Ana\n"
    invoice += "Total Months: " + str(months) + "\n"
    invoice += "Total Price: Rs. " + str(total_price) + "\n"
    invoice += "==========================\n"

    # Save invoice to a text file
    file_name = "invoice_land_" + str(kitta_number) + ".txt"  
    try:
        with open(file_name, 'w') as file:
            file.write(invoice)
        print("Invoice has been generated and saved in " + file_name)
    except IOError:
        print("Error: Unable to write to file " + file_name)
